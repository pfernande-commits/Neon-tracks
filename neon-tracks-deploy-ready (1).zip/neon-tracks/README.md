# NEON TRACKS

Juego de carreras 3D low-poly para navegador, con modo individual contra bots y salas privadas online mediante código.

## Requisitos

- Node.js 18 o superior
- npm
- Conexión a internet para cargar Three.js desde jsDelivr y la tipografía desde Google Fonts

## Ejecutar en local

```bash
npm install
npm start
```

Abre http://localhost:3000 en el navegador. Para probar el multijugador, abre la dirección en dos navegadores o dispositivos conectados al mismo servidor.

## Controles

- W / Flecha arriba: acelerar
- S / Flecha abajo: frenar / marcha atrás
- A-D / flechas izquierda-derecha: girar
- Espacio: freno de mano
- R: recolocar el coche
- Esc: salir de la carrera

## Salas online

1. Un jugador pulsa «Crear sala online».
2. Comparte el código de 6 caracteres.
3. Los amigos introducen el código y pulsan «Unirse».
4. El anfitrión pulsa «Iniciar carrera».

El servidor Socket.IO coordina las salas y retransmite el estado de los coches. El prototipo admite hasta 8 jugadores por sala.

## Publicarlo en internet

Despliega el proyecto en un servicio que admita procesos Node.js persistentes y WebSockets (por ejemplo, Render, Railway, Fly.io o un VPS).

- Build command: `npm install`
- Start command: `npm start`
- Port: usa la variable `PORT` que proporciona la plataforma.

No lo publiques como alojamiento estático: el modo online necesita que `server.js` permanezca activo y acepte conexiones Socket.IO.

## Estado y alcance de esta primera versión

Esta es una primera versión jugable/prototipo:
- Escena 3D, pista ovalada, coches, cámara de seguimiento y controles.
- Modo individual con bots visuales.
- Crear y unirse a salas online privadas.
- Estado básico de coches sincronizado entre clientes.

Pendiente para una versión de producción: físicas más avanzadas, vueltas y checkpoints validados por servidor, interpolación/extrapolación de red, reconexión, matchmaking público, selección de circuitos, editor de pistas, anti-trampas, pruebas en móviles y despliegue/monitorización.


## Configuración recomendada para Render

Crear un servicio **Web Service** conectado al repositorio GitHub que contenga estos archivos en la raíz.

- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`
- Health Check Path: `/health`
- Environment: `NODE_ENV=production`
- No definas manualmente `PORT`: Render la proporciona automáticamente.
- El servidor escucha en `0.0.0.0` y en `process.env.PORT`.

El cliente y el servidor se sirven desde el mismo dominio; Socket.IO usa la misma URL, así que no hace falta configurar una URL de backend separada.

Después del despliegue:
1. Abre la URL pública y confirma que `/health` responde `{"ok":true,"game":"Neon Tracks"}`.
2. Abre la web en dos navegadores/dispositivos.
3. En el primero crea una sala y copia el código.
4. En el segundo introduce el código y únete.
5. Comprueba que ambos nombres aparecen en la sala y que el anfitrión puede iniciar.

**Limitación conocida:** este prototipo no debe considerarse aún un juego de carreras completo: falta cerrar el circuito mediante vueltas/checkpoints, determinar el ganador de forma autoritativa en servidor y probar el comportamiento de reconexión. La sincronización actual es una base funcional, no una validación competitiva/anti-trampas.
