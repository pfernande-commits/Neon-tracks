import * as THREE from "three";

const socket = io();
const $ = id => document.getElementById(id);
const menu = $("menu"), lobby = $("lobby"), hud = $("hud"), results = $("results");
let selectedColor = "#21d4fd";
let scene, camera, renderer, clock;
let playerCar, cars = new Map(), trackGroup;
let running = false, multiplayer = false, roomCode = null, isHost = false;
let startTime = 0, elapsed = 0, finished = false, raceTimer = 0;
let speed = 0, steering = 0, yaw = 0, distance = 0, checkpoint = 0;
let keys = {}, bots = [], remotePlayers = new Map(), lastNetSend = 0;
const TRACK = { radiusX: 53, radiusZ: 34, width: 13 };
const mat = (color, roughness=.7, metalness=.05) => new THREE.MeshStandardMaterial({color, roughness, metalness});
const materials = {
  road: mat("#252e3d"), edge: mat("#21d4fd",.4,.45), grass: mat("#132b35"),
  white: mat("#eaf5ff"), dark: mat("#101827"), glass: new THREE.MeshStandardMaterial({color:"#7ddff5",metalness:.55,roughness:.18})
};

function init3D() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color("#9bc9d8");
  scene.fog = new THREE.Fog("#9bc9d8", 115, 260);
  camera = new THREE.PerspectiveCamera(58, innerWidth/innerHeight, .1, 600);
  renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:"high-performance"});
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.12;
  $("game").appendChild(renderer.domElement);
  scene.add(new THREE.HemisphereLight("#e6f8ff","#354657",2.0));
  const sun = new THREE.DirectionalLight("#fff1d5",2.8);
  sun.position.set(-55,90,30); sun.castShadow = true;
  sun.shadow.mapSize.set(2048,2048);
  sun.shadow.camera.left=-120; sun.shadow.camera.right=120; sun.shadow.camera.top=120; sun.shadow.camera.bottom=-120;
  scene.add(sun);
  buildWorld();
  clock = new THREE.Clock();
  window.addEventListener("resize", onResize);
  animate();
}
function onResize() {
  if (!camera || !renderer) return;
  camera.aspect = innerWidth/innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
}
function buildWorld() {
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(600,600), materials.grass);
  ground.rotation.x=-Math.PI/2; ground.position.y=-.8; ground.receiveShadow=true; scene.add(ground);
  // A smooth oval raceway assembled from short road segments.
  trackGroup = new THREE.Group(); scene.add(trackGroup);
  const points = [];
  for(let i=0;i<160;i++){ const a=i/160*Math.PI*2; points.push(new THREE.Vector3(Math.cos(a)*TRACK.radiusX,0,Math.sin(a)*TRACK.radiusZ)); }
  for(let i=0;i<points.length;i++){
    const a=points[i], b=points[(i+1)%points.length], mid=a.clone().add(b).multiplyScalar(.5);
    const dir=b.clone().sub(a), len=dir.length();
    const road=new THREE.Mesh(new THREE.BoxGeometry(TRACK.width,.35,len+1.0),materials.road);
    road.position.set(mid.x,0,mid.z); road.rotation.y=Math.atan2(dir.x,dir.z); road.receiveShadow=true; road.castShadow=true; trackGroup.add(road);
    const edgeGeo=new THREE.BoxGeometry(.48,.48,len+1.0);
    for(const side of [-1,1]){
      const normal=new THREE.Vector3(dir.z,0,-dir.x).normalize().multiplyScalar(side*(TRACK.width/2));
      const curb=new THREE.Mesh(edgeGeo,materials.edge); curb.position.set(mid.x+normal.x,.12,mid.z+normal.z);
      curb.rotation.y=road.rotation.y; trackGroup.add(curb);
    }
  }
  // Start/finish stripe and trackside pylons.
  const stripe=new THREE.Mesh(new THREE.BoxGeometry(TRACK.width,.05,1.1),mat("#f7fbff"));
  stripe.position.set(TRACK.radiusX, .21,0); scene.add(stripe);
  for(let i=0;i<32;i++){
    const a=i/32*Math.PI*2;
    const x=Math.cos(a)*(TRACK.radiusX+TRACK.width*.95), z=Math.sin(a)*(TRACK.radiusZ+TRACK.width*.95);
    const pylon=new THREE.Mesh(new THREE.BoxGeometry(1.1,2.8,1.1),mat(i%2?"#1b3449":"#ff5470"));
    pylon.position.set(x,1.1,z); pylon.castShadow=true; scene.add(pylon);
    const cap=new THREE.Mesh(new THREE.BoxGeometry(1.4,.2,1.4),mat("#eafaff",.3,.3));
    cap.position.set(x,2.55,z); scene.add(cap);
  }
  // Distant angular mountains.
  for(let i=0;i<38;i++){
    const a=i/38*Math.PI*2, r=145+(i%4)*12;
    const h=14+(i%7)*5;
    const mountain=new THREE.Mesh(new THREE.ConeGeometry(12+(i%3)*4,h,5),mat(i%2?"#627f91":"#7897a5"));
    mountain.position.set(Math.cos(a)*r,h/2-1,Math.sin(a)*r); mountain.rotation.y=a; scene.add(mountain);
  }
  // Floating neon arch near start.
  const arch=new THREE.Mesh(new THREE.TorusGeometry(8,.22,8,48,Math.PI),new THREE.MeshStandardMaterial({color:"#21d4fd",emissive:"#087d9b",emissiveIntensity:1.3}));
  arch.position.set(TRACK.radiusX,5,-15); arch.rotation.y=Math.PI/2; scene.add(arch);
}
function makeCar(color="#21d4fd", name="RACER") {
  const group=new THREE.Group();
  const body=new THREE.Mesh(new THREE.BoxGeometry(2.35,.62,4.1),mat(color,.32,.45));
  body.position.y=.78; body.castShadow=true; group.add(body);
  const nose=new THREE.Mesh(new THREE.ConeGeometry(1.02,1.55,4),mat(color,.28,.35));
  nose.rotation.x=Math.PI/2; nose.position.set(0,.77,-2.55); nose.scale.set(1,.8,1); group.add(nose);
  const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.55,.68,1.65),materials.glass);
  cabin.position.set(0,1.35,.15); cabin.castShadow=true; group.add(cabin);
  const wing=new THREE.Mesh(new THREE.BoxGeometry(2.8,.13,.55),mat("#111b29",.3,.3));
  wing.position.set(0,1.24,1.9); group.add(wing);
  for(const x of [-1.15,1.15]) for(const z of [-1.35,1.35]){
    const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.42,.42,.32,10),mat("#080d14",.9));
    wheel.rotation.z=Math.PI/2; wheel.position.set(x,.48,z); group.add(wheel);
  }
  const lightMat=new THREE.MeshBasicMaterial({color:"#e9fbff"});
  for(const x of [-.72,.72]){
    const lamp=new THREE.Mesh(new THREE.BoxGeometry(.35,.14,.08),lightMat);
    lamp.position.set(x,.8,-2.06); group.add(lamp);
  }
  group.userData.name=name; group.traverse(o=>{if(o.isMesh)o.castShadow=true;});
  scene.add(group); return group;
}
function placeCar(car, angle, lane=0) {
  const x=Math.cos(angle)*(TRACK.radiusX+lane), z=Math.sin(angle)*(TRACK.radiusZ+lane);
  car.position.set(x,.1,z); car.rotation.y=-Math.atan2(Math.cos(angle)*TRACK.radiusZ, -Math.sin(angle)*TRACK.radiusX);
}
function startGame({online=false, room=null, host=false, playerList=[]}={}) {
  multiplayer=online; roomCode=room; isHost=host; running=true; finished=false;
  elapsed=0; startTime=performance.now(); speed=0; steering=0; yaw=0; distance=0; checkpoint=0;
  menu.classList.add("hidden"); lobby.classList.add("hidden"); results.classList.add("hidden"); hud.classList.remove("hidden");
  $("raceMode").textContent=online?"PRIVATE MULTIPLAYER":"TIME ATTACK";
  $("raceMessage").classList.remove("hidden"); $("raceMessage").textContent="3";
  setTimeout(()=>{if(running)$("raceMessage").textContent="2";},700);
  setTimeout(()=>{if(running)$("raceMessage").textContent="1";},1400);
  setTimeout(()=>{if(running)$("raceMessage").classList.add("hidden");},2100);
  clearCars();
  playerCar=makeCar(selectedColor,$("playerName").value);
  placeCar(playerCar,0,-2.2);
  if(online){
    playerList.filter(p=>p.id!==socket.id).forEach((p,i)=>{
      const c=makeCar(p.color,p.name); placeCar(c,0,2.2+i*2.7);
      cars.set(p.id,c); remotePlayers.set(p.id,{...p,state:null});
    });
  } else {
    const count=3;
    for(let i=0;i<count;i++){
      const bot={car:makeCar(["#ff5470","#b6ff4d","#ffb84d"][i],"BOT "+(i+1)), progress:0, lane:2.2+i*2.4, pace:.00055+i*.000035, phase:i*1.5};
      bots.push(bot); placeCar(bot.car,0,bot.lane);
    }
  }
  camera.position.set(playerCar.position.x+10,9,playerCar.position.z+15);
  camera.lookAt(playerCar.position);
}
function clearCars(){
  if(playerCar){scene.remove(playerCar);playerCar=null;}
  cars.forEach(c=>scene.remove(c)); cars.clear(); remotePlayers.clear();
  bots.forEach(b=>scene.remove(b.car)); bots=[];
}
function resetCar(){
  if(!playerCar)return;
  const a=checkpoint*Math.PI*2;
  placeCar(playerCar,a,-2.2); yaw=playerCar.rotation.y; speed=0;
}
function updatePlayer(dt){
  const forward=keys.KeyW||keys.ArrowUp, back=keys.KeyS||keys.ArrowDown;
  const left=keys.KeyA||keys.ArrowLeft, right=keys.KeyD||keys.ArrowRight;
  const hand=keys.Space;
  const accel=forward?34:back?-23:0;
  speed += accel*dt;
  speed *= Math.pow(hand?.955:.987,dt*60);
  speed *= Math.pow(.996,dt*60);
  speed=THREE.MathUtils.clamp(speed,-12,48);
  const steer=(left?1:0)-(right?1:0);
  steering=THREE.MathUtils.lerp(steering,steer,.13);
  yaw += steering*dt*(.55+Math.abs(speed)*.027)*(speed<0?-1:1);
  const forwardVec=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));
  playerCar.position.addScaledVector(forwardVec,speed*dt);
  playerCar.rotation.y=yaw;
  // Soft track boundaries keep the first build playable.
  const nx=playerCar.position.x/TRACK.radiusX, nz=playerCar.position.z/TRACK.radiusZ;
  const radial=Math.sqrt(nx*nx+nz*nz);
  if(radial<.66||radial>1.36){speed*=.91;}
  playerCar.position.y=.1+Math.min(.5,Math.abs(speed)*.006);
  distance += Math.abs(speed)*dt;
  if(distance >= 290 && running){
    if(multiplayer) socket.emit("race:finish", {time: elapsed});
    showResults();
    return;
  }
  const angle=Math.atan2(playerCar.position.z/TRACK.radiusZ,playerCar.position.x/TRACK.radiusX);
  const normalized=(angle+Math.PI*2)%(Math.PI*2);
  const next=Math.floor(normalized/(Math.PI*2)*8);
  checkpoint=next;
  const target=playerCar.position.clone().add(new THREE.Vector3(Math.sin(yaw)*10,4,Math.cos(yaw)*10));
  const desired=playerCar.position.clone().add(new THREE.Vector3(Math.sin(yaw)*10,5,Math.cos(yaw)*10));
  camera.position.lerp(desired,.08); camera.lookAt(playerCar.position.x,playerCar.position.y+1,playerCar.position.z);
  $("speed").textContent=String(Math.round(Math.abs(speed)*5.1)).padStart(3,"0");
  $("speedBar").style.width=(Math.abs(speed)/48*100)+"%";
}
function updateBots(dt){
  bots.forEach(bot=>{
    bot.progress+=bot.pace*dt*60;
    const a=bot.progress%(Math.PI*2);
    const x=Math.cos(a)*(TRACK.radiusX+bot.lane), z=Math.sin(a)*(TRACK.radiusZ+bot.lane);
    bot.car.position.set(x,.1,z);
    bot.car.rotation.y=-Math.atan2(Math.cos(a)*TRACK.radiusZ,-Math.sin(a)*TRACK.radiusX);
  });
}
function updateRemote(){
  remotePlayers.forEach((p,id)=>{
    const car=cars.get(id); if(!car||!p.state)return;
    const s=p.state;
    car.position.lerp(new THREE.Vector3(s.x,s.y,s.z),.32);
    car.rotation.y=THREE.MathUtils.lerp(car.rotation.y,s.rot,.32);
  });
}
function animate(){
  requestAnimationFrame(animate);
  const dt=Math.min(clock?.getDelta()||.016,.04);
  if(running&&playerCar){
    elapsed=performance.now()-startTime;
    updatePlayer(dt);
    if(!multiplayer) updateBots(dt); else updateRemote();
    $("timer").textContent=formatTime(elapsed);
    const now=performance.now();
    if(multiplayer&&now-lastNetSend>50){
      lastNetSend=now;
      socket.emit("player:state",{x:playerCar.position.x,y:playerCar.position.y,z:playerCar.position.z,rot:playerCar.rotation.y,speed:Math.abs(speed),lap:0});
    }
  }
  if(renderer&&scene&&camera) renderer.render(scene,camera);
}
function formatTime(ms){const m=Math.floor(ms/60000),s=Math.floor(ms/1000)%60,mm=Math.floor(ms)%1000;return `${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}.${String(mm).padStart(3,"0")}`;}
function showResults(){
  running=false; finished=true; hud.classList.add("hidden"); results.classList.remove("hidden");
  $("finalTime").textContent=formatTime(elapsed);
  const rows=[{name:$("playerName").value,time:elapsed}];
  bots.forEach((b,i)=>rows.push({name:"BOT "+(i+1),time:elapsed+(i+1)*1730+Math.random()*900}));
  rows.sort((a,b)=>a.time-b.time);
  $("resultRows").innerHTML=rows.map((r,i)=>`<div class="result-row"><span>${String(i+1).padStart(2,"0")} &nbsp; ${escapeHtml(r.name)}</span><strong>${i===0&&r.name===$("playerName").value?formatTime(elapsed):formatTime(r.time)}</strong></div>`).join("");
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function toast(message){const t=$("toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600);}
function showLobby(room){
  isHost=room.hostId===socket.id; roomCode=room.code;
  $("lobbyCode").textContent=room.code; lobby.classList.remove("hidden"); menu.classList.add("hidden");
  renderLobby(room);
}
function renderLobby(room){
  $("playerCount").textContent=`${room.players.length} / 8`;
  $("playerList").innerHTML=room.players.map(p=>`<div class="player-item"><span class="player-color" style="background:${p.color};color:${p.color}"></span>${escapeHtml(p.name)}${p.id===room.hostId?" <small>HOST</small>":""}<small>${p.ready?"READY":"WAITING"}</small></div>`).join("");
  $("startBtn").disabled=!isHost;
  $("startBtn").style.opacity=isHost?"1":".4";
  $("lobbyMessage").textContent=isHost?"Eres el anfitrión. Inicia cuando todos estén listos.":"Esperando a que el anfitrión inicie la carrera.";
}
function leaveRoom(){
  socket.emit("room:leave"); roomCode=null; isHost=false;
  lobby.classList.add("hidden"); hud.classList.add("hidden"); results.classList.add("hidden"); menu.classList.remove("hidden");
  running=false; clearCars();
}
function nameAndColor(){return {name:$("playerName").value.trim()||"Racer",color:selectedColor};}

init3D();
socket.on("connect",()=>$("connection").textContent="SERVIDOR CONECTADO");
socket.on("disconnect",()=>$("connection").textContent="DESCONECTADO");
socket.on("connect_error",()=>$("connection").textContent="SIN CONEXIÓN");
socket.on("room:update",room=>{if(room.code===roomCode&& !running)renderLobby(room);});
socket.on("race:started",()=>{const room=window.currentRoom;if(room)startGame({online:true,room:roomCode,host:isHost,playerList:room.players});});
socket.on("players:state",({id,state})=>{const p=remotePlayers.get(id);if(p)p.state=state;});
socket.on("player:finished",({id,name,time})=>toast(`${name} ha terminado${time!=null?" · "+formatTime(time):""}`));
socket.on("room:update",room=>{if(room.code===roomCode)window.currentRoom=room;});
socket.on("room:update",room=>{if(room.code===roomCode&&room.status==="racing"&&!running){startGame({online:true,room:roomCode,host:isHost,playerList:room.players});}});

document.querySelectorAll(".swatch").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".swatch").forEach(b=>b.classList.remove("selected"));
  btn.classList.add("selected"); selectedColor=btn.dataset.color;
}));
$("soloBtn").addEventListener("click",()=>startGame({online:false}));
$("createBtn").addEventListener("click",()=>{
  socket.emit("room:create",nameAndColor(),res=>{
    if(!res?.ok)return toast("No se pudo crear la sala.");
    window.currentRoom=res.room; showLobby(res.room);
  });
});
$("joinBtn").addEventListener("click",()=>{
  const code=$("roomCode").value.trim().toUpperCase();
  if(code.length!==6)return toast("Introduce un código de 6 caracteres.");
  socket.emit("room:join",{...nameAndColor(),code},res=>{
    if(!res?.ok)return toast(res?.error||"No se pudo entrar.");
    window.currentRoom=res.room; showLobby(res.room);
  });
});
$("copyCode").addEventListener("click",async()=>{
  try{await navigator.clipboard.writeText(roomCode);toast("Código copiado.");}
  catch{toast("Código: "+roomCode);}
});
$("readyBtn").addEventListener("click",()=>{socket.emit("player:ready",true);$("lobbyMessage").textContent="¡Listo! Esperando al anfitrión.";});
$("startBtn").addEventListener("click",()=>{
  if(!isHost)return;
  socket.emit("race:start");
});
$("leaveLobby").addEventListener("click",leaveRoom);
$("exitRace").addEventListener("click",leaveRoom);
$("againBtn").addEventListener("click",leaveRoom);
window.addEventListener("keydown",e=>{
  if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space"].includes(e.code))e.preventDefault();
  keys[e.code]=true;
  if(e.code==="KeyR"&&running)resetCar();
  if(e.code==="Escape"&&(running||!lobby.classList.contains("hidden")))leaveRoom();
});
window.addEventListener("keyup",e=>keys[e.code]=false);
