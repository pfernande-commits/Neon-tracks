const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true, game: "Neon Tracks" }));

const rooms = new Map();
const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function makeCode() {
  let code;
  do {
    code = Array.from({ length: 6 }, () => CODE_CHARS[crypto.randomInt(CODE_CHARS.length)]).join("");
  } while (rooms.has(code));
  return code;
}
function publicRoom(room) {
  return {
    code: room.code,
    hostId: room.hostId,
    status: room.status,
    players: [...room.players.values()].map(p => ({
      id: p.id, name: p.name, color: p.color, ready: p.ready
    }))
  };
}
function emitRoom(room) {
  io.to(room.code).emit("room:update", publicRoom(room));
}
function leaveCurrentRoom(socket) {
  const code = socket.data.roomCode;
  if (!code) return;
  const room = rooms.get(code);
  socket.leave(code);
  socket.data.roomCode = null;
  if (!room) return;
  room.players.delete(socket.id);
  if (room.players.size === 0) {
    rooms.delete(code);
    return;
  }
  if (room.hostId === socket.id) room.hostId = room.players.keys().next().value;
  emitRoom(room);
}

io.on("connection", socket => {
  socket.on("room:create", ({ name, color } = {}, callback = () => {}) => {
    leaveCurrentRoom(socket);
    const code = makeCode();
    const room = {
      code, hostId: socket.id, status: "lobby",
      players: new Map(), createdAt: Date.now()
    };
    room.players.set(socket.id, {
      id: socket.id, name: cleanName(name), color: safeColor(color),
      ready: true, state: null, finished: false
    });
    rooms.set(code, room);
    socket.join(code);
    socket.data.roomCode = code;
    callback({ ok: true, room: publicRoom(room) });
    emitRoom(room);
  });

  socket.on("room:join", ({ code, name, color } = {}, callback = () => {}) => {
    const normalized = String(code || "").trim().toUpperCase();
    const room = rooms.get(normalized);
    if (!room) return callback({ ok: false, error: "No existe una sala con ese código." });
    if (room.status !== "lobby") return callback({ ok: false, error: "La carrera ya ha comenzado." });
    if (room.players.size >= 8) return callback({ ok: false, error: "La sala está llena (máximo 8 jugadores)." });
    leaveCurrentRoom(socket);
    room.players.set(socket.id, {
      id: socket.id, name: cleanName(name), color: safeColor(color),
      ready: false, state: null, finished: false
    });
    socket.join(normalized);
    socket.data.roomCode = normalized;
    callback({ ok: true, room: publicRoom(room) });
    emitRoom(room);
  });

  socket.on("player:ready", ready => {
    const room = rooms.get(socket.data.roomCode);
    const player = room?.players.get(socket.id);
    if (!player || room.status !== "lobby") return;
    player.ready = !!ready;
    emitRoom(room);
  });

  socket.on("race:start", () => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || room.hostId !== socket.id || room.status !== "lobby") return;
    room.status = "racing";
    room.startedAt = Date.now();
    for (const p of room.players.values()) { p.finished = false; p.state = null; }
    io.to(room.code).emit("race:started", { startedAt: room.startedAt });
    emitRoom(room);
  });

  socket.on("player:state", state => {
    const room = rooms.get(socket.data.roomCode);
    const player = room?.players.get(socket.id);
    if (!room || !player || room.status !== "racing" || player.finished) return;
    if (!state || ![state.x, state.y, state.z, state.rot, state.speed].every(Number.isFinite)) return;
    player.state = {
      x: clamp(state.x, -500, 500), y: clamp(state.y, -20, 100),
      z: clamp(state.z, -500, 500), rot: state.rot,
      speed: clamp(state.speed, 0, 100), lap: clamp(state.lap || 0, 0, 99)
    };
    socket.to(room.code).volatile.emit("players:state", {
      id: socket.id, state: player.state
    });
  });

  socket.on("race:finish", ({ time } = {}) => {
    const room = rooms.get(socket.data.roomCode);
    const player = room?.players.get(socket.id);
    if (!room || !player || room.status !== "racing" || player.finished) return;
    player.finished = true;
    io.to(room.code).emit("player:finished", {
      id: socket.id, name: player.name,
      time: Number.isFinite(time) ? clamp(time, 0, 3600000) : null
    });
  });

  socket.on("room:leave", () => leaveCurrentRoom(socket));
  socket.on("disconnect", () => leaveCurrentRoom(socket));
});

function cleanName(value) {
  const name = String(value || "Piloto").replace(/[<>]/g, "").trim().slice(0, 16);
  return name || "Piloto";
}
function safeColor(value) {
  return /^#[0-9a-fA-F]{6}$/.test(value || "") ? value : "#21d4fd";
}
function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }

server.listen(PORT, "0.0.0.0", () => console.log(`Neon Tracks running on 0.0.0.0:${PORT}`));
